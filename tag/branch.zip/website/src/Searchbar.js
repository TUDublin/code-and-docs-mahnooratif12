function SearchBar () {
    return(
        <div>Search Bar</div>
    )
}


export default SearchBar;
